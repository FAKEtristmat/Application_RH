package backend;

import com.formdev.flatlaf.FlatIntelliJLaf; // ou FlatDarkLaf(), selon votre préférence
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        try {
            // Appliquer le thème moderne FlatLaf (ici FlatLightLaf, vous pouvez aussi essayer FlatDarkLaf ou FlatIntelliJLaf)
            UIManager.setLookAndFeel(new FlatIntelliJLaf());
        } catch (Exception ex) {
            System.err.println("Erreur lors de l'initialisation de FlatLaf : " + ex);
        }
        
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}
