package backend;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class ApproveLeavePanel extends JPanel {
    private final MainFrame mainFrame;
    private final LeaveRequestManager leaveManager;
    private JTable requestsTable;
    private DefaultTableModel tableModel;
    private JButton approveButton;
    private JButton rejectButton;
    private JButton refreshButton;
    private JButton backButton;
    private JButton logoutButton;
    private JLabel usedDaysLabel;

    public ApproveLeavePanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        this.leaveManager = new LeaveRequestManager();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);

        createTable();
        JScrollPane scrollPane = new JScrollPane(requestsTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        approveButton = new JButton("Approuver");
        rejectButton = new JButton("Rejeter");
        refreshButton = new JButton("Rafraîchir");
        backButton = new JButton("Retour");
        buttonPanel.add(approveButton);
        buttonPanel.add(rejectButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(backButton);

        JPanel southPanel = new JPanel(new BorderLayout());
        southPanel.add(buttonPanel, BorderLayout.NORTH);

        usedDaysLabel = new JLabel("Jours déjà utilisés par l'employé : - / 30");
        usedDaysLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        southPanel.add(usedDaysLabel, BorderLayout.SOUTH);

        add(southPanel, BorderLayout.SOUTH);

        approveButton.addActionListener(e -> handleApprove());
        rejectButton.addActionListener(e -> handleReject());
        refreshButton.addActionListener(e -> refreshTable());
        backButton.addActionListener(e -> mainFrame.showPanel("main"));

        requestsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                updateUsedDaysLabel();
            }
        });

        refreshTable();
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Approbation des Congés");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(titleLabel, BorderLayout.WEST);

        logoutButton = new JButton("Déconnexion");
        logoutButton.addActionListener(e -> mainFrame.logout());
        headerPanel.add(logoutButton, BorderLayout.EAST);

        return headerPanel;
    }

    private void createTable() {
        String[] columns = {"ID", "Employé", "Dates", "Raison", "Statut"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        requestsTable = new JTable(tableModel);
    }

    private void refreshTable() {
        leaveManager.reloadData();
        tableModel.setRowCount(0);
        List<LeaveRequest> pendingRequests = leaveManager.getPendingRequests();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        for (LeaveRequest req : pendingRequests) {
            String dates = sdf.format(req.getStartDate()) + " - " + sdf.format(req.getEndDate());
            tableModel.addRow(new Object[] {
                req.getId(),
                req.getUserId(),
                dates,
                req.getReason(),
                req.getStatus()
            });
        }
    }

    private void updateUsedDaysLabel() {
        int selectedRow = requestsTable.getSelectedRow();
        if (selectedRow < 0) {
            usedDaysLabel.setText("Jours déjà utilisés par l'employé : - / 30");
            return;
        }
        Long employeeId = (Long) tableModel.getValueAt(selectedRow, 1);
        int currentYear = LocalDate.now().getYear();
        int usedDays = leaveManager.getUsedDaysInYear(employeeId, currentYear);
        usedDaysLabel.setText("Jours déjà utilisés par l'employé : " + usedDays + " / 30");
    }

    private void handleApprove() {
        int selectedRow = requestsTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(
                this,
                "Veuillez sélectionner une demande.",
                "Avertissement",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        Long requestId = (Long) tableModel.getValueAt(selectedRow, 0);
        LeaveRequest request = leaveManager.findById(requestId);
        if (request == null) {
            JOptionPane.showMessageDialog(this,
                "Demande introuvable.",
                "Erreur",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        LocalDate start = request.getStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate end = request.getEndDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        long requestedDays = ChronoUnit.DAYS.between(start, end.plusDays(1));
        int currentYear = LocalDate.now().getYear(); 
        int usedDays = leaveManager.getUsedDaysInYear(request.getUserId(), currentYear);
        if (usedDays + requestedDays > 30) {
            JOptionPane.showMessageDialog(
                this,
                "Cette demande dépasse le quota annuel de 30 jours.\n" +
                "L'employé a déjà utilisé " + usedDays + " jour(s) cette année.",
                "Quota dépassé",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }
        leaveManager.updateRequestStatus(requestId, "APPROUVÉ");
        Long employeeId = request.getUserId();
        Notification notif = new Notification(null, employeeId, "Votre demande de congé a été approuvée.", false);
        NotificationService.addNotification(notif);
        refreshTable();
    }

    private void handleReject() {
        int selectedRow = requestsTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(
                this,
                "Veuillez sélectionner une demande.",
                "Avertissement",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        Long requestId = (Long) tableModel.getValueAt(selectedRow, 0);
        leaveManager.updateRequestStatus(requestId, "REJETÉ");
        Long employeeId = (Long) tableModel.getValueAt(selectedRow, 1);
        Notification notif = new Notification(null, employeeId, "Votre demande de congé a été rejetée.", false);
        NotificationService.addNotification(notif);
        refreshTable();
    }
}
