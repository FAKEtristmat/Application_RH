package backend;

import be.quodlibet.boxable.BaseTable;
import be.quodlibet.boxable.Cell;
import be.quodlibet.boxable.Row;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDPageContentStream.AppendMode;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.Locale;

public class PDFGenerator {

    public static void generatePayslip(Employee employee) {
        PDDocument document = new PDDocument();
        PDPage page = new PDPage();
        document.addPage(page);

        float margin = 50;
        float pageWidth = page.getMediaBox().getWidth();
        float pageHeight = page.getMediaBox().getHeight();
        float tableWidth = pageWidth - 2 * margin;
        float yStart = pageHeight - margin;

        try {
            // ---- (A) HEADER : Créer, écrire et fermer le flux pour le header ----
            PDPageContentStream headerStream = new PDPageContentStream(document, page, AppendMode.OVERWRITE, true);
            headerStream.beginText();
            headerStream.setFont(PDType1Font.HELVETICA_BOLD, 20);
            headerStream.newLineAtOffset(margin, yStart);
            headerStream.showText("BULLETIN DE PAIE");
            headerStream.endText();

            headerStream.beginText();
            headerStream.setFont(PDType1Font.HELVETICA_OBLIQUE, 10);
            headerStream.newLineAtOffset(margin, yStart - 20);
            headerStream.showText("Date : " + LocalDate.now());
            headerStream.endText();

            headerStream.beginText();
            headerStream.setFont(PDType1Font.HELVETICA, 12);
            headerStream.newLineAtOffset(margin, yStart - 40);
            headerStream.showText("Employé : " + employee.getFirstName() + " " + employee.getLastName());
            headerStream.newLineAtOffset(0, -15);
            headerStream.showText("Poste : " + employee.getPosition());
            headerStream.endText();
            headerStream.close();

            // ---- (B) TABLEAU : Créer et dessiner le tableau via Boxable ----
            float yPositionTable = yStart - 80;
            float bottomMargin = 50;
            BaseTable table = new BaseTable(
                    yPositionTable,   // position Y de départ
                    bottomMargin,     // position Y limite basse
                    20,               // marge de ligne
                    tableWidth,       // largeur du tableau
                    margin,           // marge gauche
                    document, page, true, true
            );

            // En-tête du tableau
            Row<PDPage> headerRow = table.createRow(20f);
            float colRubrique = 40;
            float colBase = 20;
            float colTaux = 20;
            float colMontant = 20;

            Cell<PDPage> cellHeader1 = headerRow.createCell(colRubrique, "Rubrique");
            styleHeaderCell(cellHeader1);
            Cell<PDPage> cellHeader2 = headerRow.createCell(colBase, "Base");
            styleHeaderCell(cellHeader2);
            Cell<PDPage> cellHeader3 = headerRow.createCell(colTaux, "Taux");
            styleHeaderCell(cellHeader3);
            Cell<PDPage> cellHeader4 = headerRow.createCell(colMontant, "Montant");
            styleHeaderCell(cellHeader4);

            // Lignes du tableau (exemple fictif)
            double salaireBrut = employee.getSalary();
            double nbHeures = 151.67;
            double charges = salaireBrut * 0.22;
            double net = salaireBrut - charges;

            addRow(table, "Salaire de base", formatHeure(nbHeures) + " h", "-", formatMontant(salaireBrut));
            addRow(table, "Cotisations Sociales", "-", "22%", formatMontant(charges));
            addRow(table, "Prime exceptionnelle", "-", "N/A", formatMontant(200.0));
            net += 200.0;
            addRow(table, "Sous-Total Brut", "-", "-", formatMontant(salaireBrut + 200.0));
            addRow(table, "Net à payer", "-", "-", formatMontant(net + 200.0));

            table.draw();

            // ---- (C) FOOTER : Créer, écrire et fermer le flux pour le pied de page ----
            PDPageContentStream footerStream = new PDPageContentStream(document, page, AppendMode.APPEND, true);
            footerStream.beginText();
            footerStream.setFont(PDType1Font.HELVETICA_OBLIQUE, 10);
            footerStream.newLineAtOffset(margin, 60);
            footerStream.showText("Document généré automatiquement - Confidential");
            footerStream.endText();
            footerStream.close();

            document.save(new File("payslip_" + employee.getId() + ".pdf"));
            System.out.println("Bulletin de salaire généré avec succès !");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                document.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static void styleHeaderCell(Cell<PDPage> cell) {
        cell.setFont(PDType1Font.HELVETICA_BOLD);
        cell.setFillColor(java.awt.Color.LIGHT_GRAY);
    }

    private static void addRow(BaseTable table, String rubrique, String base, String taux, String montant) {
        Row<PDPage> row = table.createRow(15f);
        row.createCell(40, rubrique);
        row.createCell(20, base);
        row.createCell(20, taux);
        row.createCell(20, montant);
    }

    private static String formatMontant(double valeur) {
        DecimalFormat df = (DecimalFormat) DecimalFormat.getCurrencyInstance(Locale.FRANCE);
        // Remplacer les espaces fines (U+202F) par des espaces classiques
        return df.format(valeur).replace("\u202F", " ");
    }

    private static String formatHeure(double heures) {
        DecimalFormat df = new DecimalFormat("0.##");
        return df.format(heures);
    }
}
