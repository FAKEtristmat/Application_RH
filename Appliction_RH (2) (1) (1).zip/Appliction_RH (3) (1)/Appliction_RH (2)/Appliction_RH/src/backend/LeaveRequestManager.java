package backend;

import java.io.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class LeaveRequestManager {
    private static final String CSV_FILE = "data/leave_requests.csv";
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    private List<LeaveRequest> requests;
    
    public LeaveRequestManager() {
        this.requests = loadRequests();
    }
    
    public List<LeaveRequest> getAllRequests() {
        return requests;
    }
    
    private List<LeaveRequest> loadRequests() {
        List<LeaveRequest> loadedRequests = new ArrayList<>();
        File file = new File(CSV_FILE);
        if (!file.exists()) {
            return loadedRequests;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null && !line.trim().isEmpty()) {
                String[] parts = line.trim().split(",");
                if (parts.length == 6) {
                    Long id = Long.parseLong(parts[0].trim());
                    Long userId = Long.parseLong(parts[1].trim());
                    Date startDate = DATE_FORMAT.parse(parts[2].trim());
                    Date endDate = DATE_FORMAT.parse(parts[3].trim());
                    String reason = parts[4].trim();
                    String status = parts[5].trim();
                    loadedRequests.add(new LeaveRequest(
                        id,
                        userId,
                        startDate,
                        endDate,
                        reason,
                        status
                    ));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return loadedRequests;
    }
    
    private void saveRequests() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(CSV_FILE))) {
            for (LeaveRequest request : requests) {
                writer.println(String.format("%d,%d,%s,%s,%s,%s",
                    request.getId(),
                    request.getUserId(),
                    DATE_FORMAT.format(request.getStartDate()),
                    DATE_FORMAT.format(request.getEndDate()),
                    request.getReason().replace(",", " "),
                    request.getStatus()
                ));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void submitLeaveRequest(LeaveRequest request) {
        Long newId = requests.isEmpty() ? 1L : requests.get(requests.size() - 1).getId() + 1;
        request.setId(newId);
        requests.add(request);
        saveRequests();
    }
    
    public List<LeaveRequest> getPendingRequests() {
        List<LeaveRequest> pendingRequests = new ArrayList<>();
        for (LeaveRequest request : requests) {
            if ("PENDING".equals(request.getStatus()) || "EN_ATTENTE".equals(request.getStatus())) {
                pendingRequests.add(request);
            }
        }
        return pendingRequests;
    }
    
    public void updateRequestStatus(Long requestId, String newStatus) {
        for (LeaveRequest request : requests) {
            if (request.getId().equals(requestId)) {
                request.setStatus(newStatus);
                break;
            }
        }
        saveRequests();
    }
    
    public LeaveRequest findById(Long requestId) {
        for (LeaveRequest r : requests) {
            if (r.getId().equals(requestId)) {
                return r;
            }
        }
        return null;
    }
    
    public int getUsedDaysInYear(Long userId, int year) {
        int used = 0;
        for (LeaveRequest r : requests) {
            if (r.getUserId().equals(userId) && "APPROUVÉ".equalsIgnoreCase(r.getStatus())) {
                LocalDate start = r.getStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                LocalDate end = r.getEndDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                if (start.getYear() == year && end.getYear() == year) {
                    long diff = ChronoUnit.DAYS.between(start, end.plusDays(1));
                    used += diff;
                }
            }
        }
        return used;
    }
    
    // Méthode ajoutée pour forcer le rechargement des données depuis le CSV
    public void reloadData() {
        this.requests = loadRequests();
    }
}
