package backend;

import backend.Employee;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SalaryChartPanel extends JPanel {
    private ChartPanel chartPanel;

    public SalaryChartPanel() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(200, 300));
    }

    public void updateChart(List<Employee> employees) {
        // Calculer la moyenne des salaires par poste
        Map<String, Double> averageSalaries = employees.stream()
            .collect(Collectors.groupingBy(
                Employee::getPosition,
                Collectors.averagingDouble(Employee::getSalary)
            ));

        // Créer le dataset
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (Map.Entry<String, Double> entry : averageSalaries.entrySet()) {
            dataset.addValue(entry.getValue(), "Salaire", entry.getKey());
        }

        // Créer le graphique
        JFreeChart chart = ChartFactory.createBarChart(
            "Salaire moyen par poste",
            "Poste",
            "Salaire (€)",
            dataset,
            PlotOrientation.VERTICAL,
            false, // pas de légende
            true,  // tooltips
            false  // pas d'URLs
        );

        // Personnaliser l'apparence
        CategoryPlot plot = chart.getCategoryPlot();
        plot.setBackgroundPaint(Color.WHITE);
        plot.setRangeGridlinePaint(Color.GRAY);
        
        // Personnaliser l'axe des catégories
        CategoryAxis domainAxis = plot.getDomainAxis();
        domainAxis.setCategoryLabelPositions(org.jfree.chart.axis.CategoryLabelPositions.UP_45);
        
        // Personnaliser l'axe des valeurs
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setNumberFormatOverride(java.text.NumberFormat.getCurrencyInstance());

        // Mettre à jour ou créer le ChartPanel
        if (chartPanel != null) {
            remove(chartPanel);
        }
        chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(380, 280));
        add(chartPanel, BorderLayout.CENTER);

        // Rafraîchir le panel
        revalidate();
        repaint();
    }
}