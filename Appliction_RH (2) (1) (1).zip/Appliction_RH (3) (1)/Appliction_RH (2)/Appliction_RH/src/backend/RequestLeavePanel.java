package backend;

import com.toedter.calendar.JDateChooser;
import java.awt.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import javax.swing.*;

public class RequestLeavePanel extends JPanel {
    private MainFrame mainFrame;
    private JDateChooser startDateChooser;
    private JDateChooser endDateChooser;
    private JTextArea reasonArea;
    private LeaveRequestManager leaveRequestManager;
    private JLabel usedDaysLabel;

    public RequestLeavePanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        this.leaveRequestManager = new LeaveRequestManager();
        setLayout(new BorderLayout());
        add(createHeaderPanel(), BorderLayout.NORTH);
        add(createFormPanel(), BorderLayout.CENTER);
        updateUsedDaysLabel();
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel titleLabel = new JLabel("Demande de congé");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        JButton logoutButton = new JButton("Déconnexion");
        logoutButton.addActionListener(e -> mainFrame.logout());
        headerPanel.add(logoutButton, BorderLayout.EAST);
        
        usedDaysLabel = new JLabel("Jours déjà utilisés : ?");
        usedDaysLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        usedDaysLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        headerPanel.add(usedDaysLabel, BorderLayout.SOUTH);
        
        return headerPanel;
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Date de début:"), gbc);
        gbc.gridx = 1;
        startDateChooser = new JDateChooser();
        formPanel.add(startDateChooser, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Date de fin:"), gbc);
        gbc.gridx = 1;
        endDateChooser = new JDateChooser();
        formPanel.add(endDateChooser, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Raison de la demande:"), gbc);
        gbc.gridx = 1;
        reasonArea = new JTextArea(3, 20);
        reasonArea.setLineWrap(true);
        reasonArea.setWrapStyleWord(true);
        formPanel.add(new JScrollPane(reasonArea), gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton submitButton = new JButton("Soumettre");
        JButton backButton = new JButton("Retour");
        buttonPanel.add(submitButton);
        buttonPanel.add(backButton);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        formPanel.add(buttonPanel, gbc);

        submitButton.addActionListener(e -> {
            if (startDateChooser.getDate() == null || endDateChooser.getDate() == null) {
                JOptionPane.showMessageDialog(this, 
                    "Veuillez sélectionner les dates de début et de fin", 
                    "Erreur", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (startDateChooser.getDate().after(endDateChooser.getDate())) {
                JOptionPane.showMessageDialog(this, 
                    "La date de début doit être antérieure à la date de fin", 
                    "Erreur", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            LocalDate start = startDateChooser.getDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate end = endDateChooser.getDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            long requestedDays = ChronoUnit.DAYS.between(start, end.plusDays(1));
            int currentYear = LocalDate.now().getYear();
            // Recharger les données pour obtenir les dernières demandes
            leaveRequestManager.reloadData();
            int usedDays = leaveRequestManager.getUsedDaysInYear(mainFrame.getCurrentUser().getId(), currentYear);
            if (usedDays + requestedDays > 30) {
                JOptionPane.showMessageDialog(this,
                    "Vous n'avez pas assez de jours disponibles.\n" +
                    "Vous avez déjà utilisé " + usedDays + " jour(s) sur 30.",
                    "Quota dépassé",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            LeaveRequest request = new LeaveRequest(
                null,
                mainFrame.getCurrentUser().getId(),
                startDateChooser.getDate(),
                endDateChooser.getDate(),
                reasonArea.getText(),
                "EN_ATTENTE"
            );
            try {
                leaveRequestManager.submitLeaveRequest(request);
                JOptionPane.showMessageDialog(this, 
                    "Demande de congé soumise avec succès", 
                    "Succès", 
                    JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                updateUsedDaysLabel();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, 
                    "Erreur lors de la soumission: " + ex.getMessage(), 
                    "Erreur", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });

        backButton.addActionListener(e -> mainFrame.showPanel("main"));
        return formPanel;
    }
    
    private void updateUsedDaysLabel() {
        // Recharge les données avant de recalculer le compteur
        leaveRequestManager.reloadData();
        if (mainFrame.getCurrentUser() != null) {
            int currentYear = LocalDate.now().getYear();
            int usedDays = leaveRequestManager.getUsedDaysInYear(mainFrame.getCurrentUser().getId(), currentYear);
            usedDaysLabel.setText("Jours déjà utilisés cette année : " + usedDays + " / 30");
        }
    }
    
    private void clearForm() {
        startDateChooser.setDate(null);
        endDateChooser.setDate(null);
        reasonArea.setText("");
    }
}
