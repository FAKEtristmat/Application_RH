package backend;

import java.util.List;
import java.util.ArrayList;

public class EmployeeService {
    private static final String EMPLOYEES_FILE = "data/employees.csv";

    public List<Employee> getEmployeesByUser(User currentUser) {
        List<String[]> records = CsvManager.readCsv(EMPLOYEES_FILE);
        List<Employee> employees = new ArrayList<>();

        // Skip header row
        for (int i = 1; i < records.size(); i++) {
            String[] record = records.get(i);
            Employee emp = new Employee(
                Long.parseLong(record[0]),
                record[1],
                record[2],
                record[3],
                Double.parseDouble(record[4]),
                Long.parseLong(record[5])
            );

            if (currentUser.getRole() == UserRole.EMPLOYEE) {
                if (emp.getUserId().equals(currentUser.getId())) {
                    employees.add(emp);
                }
            } else {
                employees.add(emp);
            }
        }
        return employees;
    }
    
    

    public void addEmployee(Employee employee) {
        List<String[]> records = CsvManager.readCsv(EMPLOYEES_FILE);
        String[] newRecord = {
            String.valueOf(employee.getId()),
            employee.getFirstName(),
            employee.getLastName(),
            employee.getPosition(),
            String.valueOf(employee.getSalary()),
            String.valueOf(employee.getUserId())
        };
        records.add(newRecord);
        CsvManager.writeCsv(EMPLOYEES_FILE, records);
    }

    public void deleteEmployee(Long id) {
        List<String[]> records = CsvManager.readCsv(EMPLOYEES_FILE);
        records.removeIf(record -> record[0].equals(String.valueOf(id)));
        CsvManager.writeCsv(EMPLOYEES_FILE, records);
    }

    public void updateEmployee(Employee employee) {
        List<String[]> records = CsvManager.readCsv(EMPLOYEES_FILE);
        for (String[] record : records) {
            if (record[0].equals(String.valueOf(employee.getId()))) {
                record[1] = employee.getFirstName();
                record[2] = employee.getLastName();
                record[3] = employee.getPosition();
                record[4] = String.valueOf(employee.getSalary());
                record[5] = String.valueOf(employee.getUserId());
                break;
            }
        }
        CsvManager.writeCsv(EMPLOYEES_FILE, records);
    }
    
}
