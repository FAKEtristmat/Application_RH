package backend;

import javax.swing.*;
import java.awt.*;

public class AddEmployeePanel extends JPanel {
    private JTextField firstNameField, lastNameField, positionField, salaryField, userIdField;
    private JButton addButton, backButton;
    private EmployeeService employeeService;
    private MainFrame mainFrame;

    public AddEmployeePanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        this.employeeService = new EmployeeService();
        setupUI();
    }

    private void setupUI() {
        setLayout(new BorderLayout(20, 20));
        setBackground(AppTheme.BACKGROUND);

        // Panel d'en-tête
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);

        // Panel principal de formulaire
        JPanel formPanel = createFormPanel();
        add(formPanel, BorderLayout.CENTER);

        // Panel de boutons
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout(15, 15));
        headerPanel.setBackground(AppTheme.BACKGROUND);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));

        // Bouton Retour (à gauche)
        backButton = createStyledButton("Retour", AppTheme.SECONDARY);
        backButton.addActionListener(e -> mainFrame.showPanel("main"));
        headerPanel.add(backButton, BorderLayout.WEST);

        // Titre au centre
        JLabel titleLabel = new JLabel("Ajouter un employé");
        titleLabel.setFont(AppTheme.TITLE_FONT);
        titleLabel.setForeground(AppTheme.PRIMARY);
        headerPanel.add(titleLabel, BorderLayout.CENTER);

        // Bouton Déconnexion (à droite)
        JButton logoutButton = createStyledButton("Déconnexion", AppTheme.DANGER);
        logoutButton.addActionListener(e -> mainFrame.logout());
        headerPanel.add(logoutButton, BorderLayout.EAST);

        return headerPanel;
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(AppTheme.BACKGROUND);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Création des champs
        firstNameField = createStyledTextField();
        lastNameField = createStyledTextField();
        positionField = createStyledTextField();
        salaryField = createStyledTextField();
        userIdField = createStyledTextField();

        // Ajout des composants avec labels
        addFormRow(formPanel, "Prénom:", firstNameField, 0, gbc);
        addFormRow(formPanel, "Nom:", lastNameField, 1, gbc);
        addFormRow(formPanel, "Poste:", positionField, 2, gbc);
        addFormRow(formPanel, "Salaire:", salaryField, 3, gbc);
        addFormRow(formPanel, "ID Utilisateur:", userIdField, 4, gbc);

        return formPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBackground(AppTheme.BACKGROUND);

        addButton = createStyledButton("Ajouter Employé", AppTheme.SUCCESS);
        addButton.addActionListener(e -> handleAddEmployee());

        buttonPanel.add(addButton);
        return buttonPanel;
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFont(AppTheme.BUTTON_FONT);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(150, 40));
        return button;
    }

    private JTextField createStyledTextField() {
        JTextField field = new JTextField(20);
        field.setPreferredSize(new Dimension(250, 35));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(AppTheme.SECONDARY),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        field.setFont(AppTheme.NORMAL_FONT);
        return field;
    }

    private void addFormRow(JPanel panel, String labelText, JComponent component, int row, GridBagConstraints gbc) {
        gbc.gridy = row;
        
        gbc.gridx = 0;
        gbc.weightx = 0.3;
        JLabel label = new JLabel(labelText);
        label.setFont(AppTheme.NORMAL_FONT);
        label.setForeground(AppTheme.TEXT);
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.7;
        panel.add(component, gbc);
    }

    private void handleAddEmployee() {
        try {
            String firstName = firstNameField.getText();
            String lastName = lastNameField.getText();
            String position = positionField.getText();
            Double salary = Double.parseDouble(salaryField.getText());
            Long userId = Long.parseLong(userIdField.getText());

            if (firstName.isEmpty() || lastName.isEmpty() || position.isEmpty()) {
                showError("Veuillez remplir tous les champs.");
                return;
            }

            // Utilisons null pour l'ID car il sera géré par le service
            Employee newEmployee = new Employee(null, firstName, lastName, position, salary, userId);

            employeeService.addEmployee(newEmployee);
            showSuccess("Employé ajouté avec succès!");
            clearFields();
            mainFrame.showPanel("main");

        } catch (NumberFormatException ex) {
            showError("Veuillez entrer des valeurs numériques valides pour le salaire et l'ID utilisateur.");
        } catch (Exception ex) {
            showError("Erreur lors de l'ajout de l'employé: " + ex.getMessage());
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Erreur", JOptionPane.ERROR_MESSAGE);
    }

    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Succès", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearFields() {
        firstNameField.setText("");
        lastNameField.setText("");
        positionField.setText("");
        salaryField.setText("");
        userIdField.setText("");
    }
}
