package backend;

import java.util.Date;

public class LeaveRequest {
    private Long id;
    private Long userId;
    private Date startDate;
    private Date endDate;
    private String reason;
    private String status;

    public LeaveRequest(Long id, Long userId, Date startDate, Date endDate, String reason, String status) {
        this.id = id;
        this.userId = userId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.reason = reason;
        this.status = status;
    }

    // Getters
    public Long getId() { return id; }
    public Long getUserId() { return userId; }
    public Date getStartDate() { return startDate; }
    public Date getEndDate() { return endDate; }
    public String getReason() { return reason; }
    public String getStatus() { return status; }

    // Setters
    public void setId(Long id) { this.id = id; }
    public void setUserId(Long userId) { this.userId = userId; }
    public void setStartDate(Date startDate) { this.startDate = startDate; }
    public void setEndDate(Date endDate) { this.endDate = endDate; }
    public void setReason(String reason) { this.reason = reason; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "LeaveRequest{" +
                "id=" + id +
                ", userId=" + userId +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", reason='" + reason + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}