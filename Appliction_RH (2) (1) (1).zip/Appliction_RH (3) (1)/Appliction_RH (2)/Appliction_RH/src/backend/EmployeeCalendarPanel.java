package backend;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.List;

public class EmployeeCalendarPanel extends JPanel {
    private User currentUser;
    private LeaveRequestManager leaveManager;

    public EmployeeCalendarPanel(User user, LeaveRequestManager leaveManager) {
        this.currentUser = user;
        this.leaveManager = leaveManager;

        setLayout(new BorderLayout());
        add(createCalendarPanel(), BorderLayout.CENTER);
    }

    /**
     * Si vous voulez recharger le calendrier quand on appelle updateData, par exemple.
     */
    public void reloadCalendar(User user) {
        this.currentUser = user;
        removeAll();
        add(createCalendarPanel(), BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private JPanel createCalendarPanel() {
        JPanel panel = new JPanel(new GridLayout(0, 7, 2, 2));
        panel.setBackground(Color.WHITE);

        // En-têtes : Lundi -> Dimanche
        String[] daysOfWeek = {"Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"};
        for (String day : daysOfWeek) {
            JLabel lbl = new JLabel(day, SwingConstants.CENTER);
            lbl.setOpaque(true);
            lbl.setBackground(Color.LIGHT_GRAY);
            panel.add(lbl);
        }

        // On se limite au mois actuel pour l’exemple
        LocalDate now = LocalDate.now();
        int displayedMonth = now.getMonthValue();
        int displayedYear = now.getYear();
        LocalDate firstOfMonth = LocalDate.of(displayedYear, displayedMonth, 1);
        int lengthOfMonth = firstOfMonth.lengthOfMonth();

        // Jour de la semaine (Lundi=1, Mardi=2, ... Dimanche=7)
        int firstDayOfWeek = firstOfMonth.getDayOfWeek().getValue();
        int blanksBefore = (firstDayOfWeek == 1) ? 0 : (firstDayOfWeek - 1);

        // Cases vides avant le 1er si le mois ne commence pas un lundi
        for (int i = 0; i < blanksBefore; i++) {
            panel.add(new JLabel(""));
        }

        // Récupérer les dates approuvées pour l'utilisateur
        Set<LocalDate> approvedDates = getApprovedDatesForUser(currentUser);

        // Ajouter les jours du mois
        for (int day = 1; day <= lengthOfMonth; day++) {
            LocalDate date = LocalDate.of(displayedYear, displayedMonth, day);
            JLabel dayLabel = new JLabel(String.valueOf(day), SwingConstants.CENTER);
            dayLabel.setOpaque(true);

            if (approvedDates.contains(date)) {
                dayLabel.setBackground(Color.GREEN); 
            } else {
                dayLabel.setBackground(Color.WHITE);
            }
            panel.add(dayLabel);
        }

        return panel;
    }

    /**
     * Renvoie l'ensemble des dates (LocalDate) approuvées pour l'utilisateur.
     */
    private Set<LocalDate> getApprovedDatesForUser(User user) {
        Set<LocalDate> result = new HashSet<>();
        // Vous pouvez ajouter une méthode getAllRequests() dans LeaveRequestManager
        // ou filtrer par user dans getPendingRequests(). Ici, on récupère tout puis on filtre.
        List<LeaveRequest> allRequests = leaveManager.getAllRequests();

        for (LeaveRequest req : allRequests) {
            // Vérifier user + statut APPROUVÉ
            if (req.getUserId().equals(user.getId()) && "APPROUVÉ".equalsIgnoreCase(req.getStatus())) {
                // Convertir Date -> LocalDate
                LocalDate start = req.getStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                LocalDate end = req.getEndDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                
                // Ajouter chaque jour de la plage
                LocalDate d = start;
                while (!d.isAfter(end)) {
                    result.add(d);
                    d = d.plusDays(1);
                }
            }
        }
        return result;
    }
}
