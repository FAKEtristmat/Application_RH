// backend/dao/CsvManager.java
package backend;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class CsvManager {
    private static final String DATA_DIR = "data";
    private static final String USERS_FILE = "data/users.csv";
    private static final String EMPLOYEES_FILE = "data/employees.csv";

    static {
        initializeDataDirectory();
    }

    private static void initializeDataDirectory() {
        try {
            Files.createDirectories(Paths.get(DATA_DIR));
            
            // Créer les fichiers s'ils n'existent pas
            if (!Files.exists(Paths.get(USERS_FILE))) {
                createUsersFile();
            }
            if (!Files.exists(Paths.get(EMPLOYEES_FILE))) {
                createEmployeesFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void createUsersFile() throws IOException {
        List<String> defaultUsers = Arrays.asList(
            "id,username,password,role",
            "1,admin,admin123,ADMIN",
            "2,manager,manager123,MANAGER",
            "3,employee,employee123,EMPLOYEE"
        );
        Files.write(Paths.get(USERS_FILE), defaultUsers);
    }

    private static void createEmployeesFile() throws IOException {
        List<String> defaultEmployees = Arrays.asList(
            "id,firstName,lastName,position,salary,userId",
            "1,John,Doe,Directeur RH,75000.0,1",
            "2,Jane,Smith,Manager,60000.0,2",
            "3,Bob,Jones,Développeur,45000.0,3"
        );
        Files.write(Paths.get(EMPLOYEES_FILE), defaultEmployees);
    }

    public static List<String[]> readCsv(String filePath) {
        List<String[]> records = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                records.add(line.split(","));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return records;
    }

    public static void writeCsv(String filePath, List<String[]> records) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (String[] record : records) {
                bw.write(String.join(",", record));
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}