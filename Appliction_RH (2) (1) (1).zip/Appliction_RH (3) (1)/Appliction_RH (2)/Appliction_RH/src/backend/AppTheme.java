package backend;

import java.awt.Color;
import java.awt.Font;

public class AppTheme {
    // Couleurs principales
    public static final Color PRIMARY = new Color(0, 123, 255);    // Bleu
    public static final Color SECONDARY = new Color(108, 117, 125); // Gris
    public static final Color SUCCESS = new Color(40, 167, 69);    // Vert
    public static final Color DANGER = new Color(220, 53, 69);     // Rouge
    public static final Color BACKGROUND = new Color(248, 249, 250); // Gris très clair
    public static final Color TEXT = new Color(33, 37, 41);        // Gris foncé

    // Styles de police
    public static final Font TITLE_FONT = new Font("Arial", Font.BOLD, 24);
    public static final Font SUBTITLE_FONT = new Font("Arial", Font.BOLD, 18);
    public static final Font NORMAL_FONT = new Font("Arial", Font.PLAIN, 14);
    public static final Font BUTTON_FONT = new Font("Arial", Font.BOLD, 12);
}