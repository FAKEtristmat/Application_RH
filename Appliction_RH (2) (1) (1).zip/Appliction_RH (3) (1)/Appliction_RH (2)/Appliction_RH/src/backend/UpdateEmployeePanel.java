package backend;

import javax.swing.*;
import java.awt.*;

public class UpdateEmployeePanel extends JPanel {
    private final MainFrame mainFrame;
    private final EmployeeService employeeService;
    private final Employee employee;

    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField positionField;
    private JTextField salaryField;
    private JButton updateButton;
    private JButton backButton;

    public UpdateEmployeePanel(MainFrame mainFrame, Employee employee) {
        this.mainFrame = mainFrame;
        this.employee = employee;
        this.employeeService = new EmployeeService();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header Panel
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = createFormPanel();
        add(formPanel, BorderLayout.CENTER);

        // Buttons Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        updateButton = new JButton("Mettre à jour");
        backButton = new JButton("Retour");

        updateButton.addActionListener(e -> handleUpdate());
        backButton.addActionListener(e -> mainFrame.showPanel("main"));

        buttonPanel.add(updateButton);
        buttonPanel.add(backButton);
        add(buttonPanel, BorderLayout.SOUTH);

        populateFields();
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Titre à gauche
        JLabel titleLabel = new JLabel("Modification d'un Employé");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        // Bouton Déconnexion à droite
        JButton logoutButton = new JButton("Déconnexion");
        logoutButton.addActionListener(e -> mainFrame.logout());
        headerPanel.add(logoutButton, BorderLayout.EAST);
        
        return headerPanel;
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Création des champs
        firstNameField = new JTextField(20);
        lastNameField = new JTextField(20);
        positionField = new JTextField(20);
        salaryField = new JTextField(20);

        addFormField(formPanel, "Prénom:", firstNameField, gbc);
        addFormField(formPanel, "Nom:", lastNameField, gbc);
        addFormField(formPanel, "Poste:", positionField, gbc);
        addFormField(formPanel, "Salaire:", salaryField, gbc);

        return formPanel;
    }

    private void addFormField(JPanel panel, String label, JTextField field, GridBagConstraints gbc) {
        gbc.gridx = 0;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = 1;
        panel.add(field, gbc);
        gbc.gridy++;
    }

    private void populateFields() {
        firstNameField.setText(employee.getFirstName());
        lastNameField.setText(employee.getLastName());
        positionField.setText(employee.getPosition());
        salaryField.setText(String.valueOf(employee.getSalary()));
    }

    private void handleUpdate() {
        // Implémentation de la mise à jour
        try {
            String firstName = firstNameField.getText();
            String lastName = lastNameField.getText();
            String position = positionField.getText();
            Double salary = Double.parseDouble(salaryField.getText());

            if (firstName.isEmpty() || lastName.isEmpty() || position.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Mise à jour de l'employé
            employee.setFirstName(firstName);
            employee.setLastName(lastName);
            employee.setPosition(position);
            employee.setSalary(salary);
            employeeService.updateEmployee(employee);

            JOptionPane.showMessageDialog(this, "Employé mis à jour avec succès !");
            mainFrame.showPanel("main");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Veuillez entrer un salaire valide.", "Erreur", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erreur lors de la mise à jour: " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }
}
