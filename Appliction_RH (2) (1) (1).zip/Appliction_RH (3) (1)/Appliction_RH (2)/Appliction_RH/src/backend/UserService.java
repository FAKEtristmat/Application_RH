package backend;

import backend.User;
import backend.UserRole;
import backend.CsvManager;
import java.util.List;

public class UserService {
    private static final String USERS_FILE = "data/users.csv";

    public User authenticate(String username, String password) {
        List<String[]> records = CsvManager.readCsv(USERS_FILE);
        
        // Skip header row
        for (int i = 1; i < records.size(); i++) {
            String[] record = records.get(i);
            if (record[1].equals(username) && record[2].equals(password)) {
                return new User(
                    Long.parseLong(record[0]),
                    record[1],
                    record[2],
                    UserRole.valueOf(record[3])
                );
            }
        }
        return null;
    }
}