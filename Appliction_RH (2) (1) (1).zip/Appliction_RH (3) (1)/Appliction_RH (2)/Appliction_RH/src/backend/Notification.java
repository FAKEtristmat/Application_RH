package backend;

public class Notification {
    private Long id;
    private Long userId;
    private String message;
    private boolean read;

    public Notification(Long id, Long userId, String message, boolean read) {
        this.id = id;
        this.userId = userId;
        this.message = message;
        this.read = read;
    }

    // Getters
    public Long getId() {
        return id;
    }
    public Long getUserId() {
        return userId;
    }
    public String getMessage() {
        return message;
    }
    public boolean isRead() {
        return read;
    }

    // Setters
    public void setId(Long id) {
        this.id = id;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public void setRead(boolean read) {
        this.read = read;
    }
}
