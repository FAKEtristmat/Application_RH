package backend;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.NumberFormat;
import java.util.List;

public class MainPanel extends JPanel {
    private JTable employeeTable;
    private DefaultTableModel tableModel;
    private EmployeeService employeeService;
    private SalaryChartPanel salaryChartPanel;
    private EmployeeCalendarPanel employeeCalendarPanel; // Pour EMPLOYEE
    private JButton notifButton; // Bouton cloche pour notifications

    private JButton addButton, updateButton, deleteButton, requestLeaveButton, approveLeaveButton, generatePayslipButton;
    private MainFrame mainFrame;
    
    // Panel central (contient la table et, en bas, le graphique ou le calendrier)
    private JPanel centerPanel;
    private JPanel headerPanel;

    public MainPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        this.employeeService = new EmployeeService();
        this.salaryChartPanel = new SalaryChartPanel();
        this.employeeCalendarPanel = null; 
        setupUI();
    }

    private void setupUI() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Création du header avec titre, notifications et déconnexion
        headerPanel = new JPanel(new BorderLayout());
        
        // Titre
        JLabel titleLabel = new JLabel("Gestion des Employés");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        // Panel de droite pour les boutons
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 5));
        rightPanel.setOpaque(false);
        
        // Bouton notifications
        notifButton = new JButton("🔔");
        notifButton.setPreferredSize(new Dimension(50, 50));
        notifButton.addActionListener(e -> showNotifications());
        rightPanel.add(notifButton);
        
        // Bouton Déconnexion
        JButton logoutButton = new JButton("Déconnexion");
        logoutButton.addActionListener(e -> mainFrame.logout());
        rightPanel.add(logoutButton);
        
        headerPanel.add(rightPanel, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // Panel central
        centerPanel = new JPanel(new BorderLayout());
        String[] columns = {"Nom", "Prénom", "Poste", "Salaire", "ID", "User ID"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        employeeTable = new JTable(tableModel);
        employeeTable.getTableHeader().setReorderingAllowed(false);

        // Formatage des salaires
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
        employeeTable.getColumnModel().getColumn(3).setCellRenderer(
            (table, value, isSelected, hasFocus, row, column) -> {
                JLabel label = new JLabel();
                if (value != null) {
                    label.setText(currencyFormat.format(value));
                    label.setHorizontalAlignment(SwingConstants.RIGHT);
                }
                return label;
            }
        );

        JScrollPane scrollPane = new JScrollPane(employeeTable);
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);

        // Panneau de boutons en bas
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(Color.WHITE);
        deleteButton = new JButton("Supprimer");
        updateButton = new JButton("Modifier");
        addButton = new JButton("Ajouter un Employé");
        requestLeaveButton = new JButton("Demander un Congé");
        approveLeaveButton = new JButton("Approuver les Congés");
        generatePayslipButton = new JButton("Générer Bulletin de Salaire");

        buttonPanel.add(deleteButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(addButton);
        buttonPanel.add(requestLeaveButton);
        buttonPanel.add(approveLeaveButton);
        buttonPanel.add(generatePayslipButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Actions
        addButton.addActionListener(e -> mainFrame.showPanel("addEmployee"));
        updateButton.addActionListener(e -> {
            int selectedRow = employeeTable.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(MainPanel.this, "Veuillez sélectionner un employé à modifier.", "Avertissement", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Employee emp = getEmployeeFromTable(selectedRow);
            mainFrame.showUpdateEmployeePanel(emp);
        });
        deleteButton.addActionListener(e -> {
            int selectedRow = employeeTable.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(MainPanel.this, "Veuillez sélectionner un employé à supprimer.", "Avertissement", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(MainPanel.this, "Êtes-vous sûr de vouloir supprimer cet employé ?", "Confirmation", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                Employee emp = getEmployeeFromTable(selectedRow);
                employeeService.deleteEmployee(emp.getId());
                refreshTable();
            }
        });
        requestLeaveButton.addActionListener(e -> mainFrame.showRequestLeavePanel());
        approveLeaveButton.addActionListener(e -> mainFrame.showApproveLeavePanel());
        generatePayslipButton.addActionListener(e -> {
            int selectedRow = employeeTable.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(MainPanel.this, "Veuillez sélectionner un employé.", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }
            Employee emp = getEmployeeFromTable(selectedRow);
            PDFGenerator.generatePayslip(emp);
        });
    }

    /**
     * Met à jour la table et le panneau bas en fonction de l'utilisateur connecté,
     * et met à jour l'icône notifications (pour les EMPLOYEE).
     */
    public void updateData(User user) {
        // Mise à jour de la table
        tableModel.setRowCount(0);
        List<Employee> employees = employeeService.getEmployeesByUser(user);
        for (Employee emp : employees) {
            tableModel.addRow(new Object[]{
                emp.getLastName(),
                emp.getFirstName(),
                emp.getPosition(),
                emp.getSalary(),
                emp.getId(),
                emp.getUserId()
            });
        }

        // Retirer le panneau bas précédent
        centerPanel.remove(salaryChartPanel);
        if (employeeCalendarPanel != null) {
            centerPanel.remove(employeeCalendarPanel);
        }

        // Mettre à jour la cloche de notifications (pour EMPLOYEE)
        if (user.getRole() == UserRole.EMPLOYEE) {
            List<Notification> unread = NotificationService.getUnreadNotifications(user.getId());
            int count = unread.size();
            // Met à jour le texte du bouton (ex: "🔔 (2)")
            if (count > 0) {
                notifButton.setText("🔔 (" + count + ")");
            } else {
                notifButton.setText("🔔");
            }
            // On affiche le panneau calendrier pour les employés
            if (employeeCalendarPanel == null) {
                employeeCalendarPanel = new EmployeeCalendarPanel(user, new LeaveRequestManager());
            } else {
                employeeCalendarPanel.reloadCalendar(user);
            }
            centerPanel.add(employeeCalendarPanel, BorderLayout.SOUTH);

            // Pour les employés, masquer d'autres boutons
            requestLeaveButton.setVisible(true);
            approveLeaveButton.setVisible(false);
            generatePayslipButton.setVisible(false);
            addButton.setVisible(false);
            updateButton.setVisible(false);
            deleteButton.setVisible(false);
        } else if (user.getRole() == UserRole.MANAGER) {
            salaryChartPanel.updateChart(employees);
            centerPanel.add(salaryChartPanel, BorderLayout.SOUTH);
            requestLeaveButton.setVisible(false);
            approveLeaveButton.setVisible(true);
            generatePayslipButton.setVisible(true);
            addButton.setVisible(true);
            updateButton.setVisible(true);
            deleteButton.setVisible(true);
        } else if (user.getRole() == UserRole.ADMIN) {
            salaryChartPanel.updateChart(employees);
            centerPanel.add(salaryChartPanel, BorderLayout.SOUTH);
            requestLeaveButton.setVisible(false);
            approveLeaveButton.setVisible(false);
            generatePayslipButton.setVisible(true);
            addButton.setVisible(true);
            updateButton.setVisible(true);
            deleteButton.setVisible(true);
        }

        centerPanel.revalidate();
        centerPanel.repaint();
    }

    private void showNotifications() {
        User user = mainFrame.getCurrentUser();
        if (user == null || user.getRole() != UserRole.EMPLOYEE) return;
        List<Notification> unreadNotifs = NotificationService.getUnreadNotifications(user.getId());
        if (unreadNotifs.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Aucune notification.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (Notification n : unreadNotifs) {
                sb.append("- ").append(n.getMessage()).append("\n");
            }
            JOptionPane.showMessageDialog(this, sb.toString(), "Notifications", JOptionPane.INFORMATION_MESSAGE);
            // Marquer toutes comme lues
            for (Notification n : unreadNotifs) {
                NotificationService.markAsRead(n.getId());
            }
            // Mettre à jour le bouton
            notifButton.setText("🔔");
        }
    }

    private Employee getEmployeeFromTable(int row) {
        Long id = Long.parseLong(employeeTable.getValueAt(row, 4).toString());
        String firstName = employeeTable.getValueAt(row, 1).toString();
        String lastName = employeeTable.getValueAt(row, 0).toString();
        String position = employeeTable.getValueAt(row, 2).toString();
        Double salary = Double.parseDouble(employeeTable.getValueAt(row, 3).toString());
        Long userId = Long.parseLong(employeeTable.getValueAt(row, 5).toString());
        return new Employee(id, firstName, lastName, position, salary, userId);
    }

    private void refreshTable() {
        User currentUser = mainFrame.getCurrentUser();
        updateData(currentUser);
    }
}
