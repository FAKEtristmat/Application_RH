package backend;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private CardLayout cardLayout;
    private JPanel contentPanel;
    private LoginPanel loginPanel;
    private MainPanel mainPanel;
    private AddEmployeePanel addEmployeePanel;
    private RequestLeavePanel requestLeavePanel;
    private ApproveLeavePanel approveLeavePanel;
    private UpdateEmployeePanel updateEmployeePanel;
    private User currentUser;

    public MainFrame() {
        setTitle("Application RH");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // Initialize components
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        loginPanel = new LoginPanel(this);
        mainPanel = new MainPanel(this);
        addEmployeePanel = new AddEmployeePanel(this);
        requestLeavePanel = new RequestLeavePanel(this);
        approveLeavePanel = new ApproveLeavePanel(this);

        // Add panels
        contentPanel.add(loginPanel, "login");
        contentPanel.add(mainPanel, "main");
        contentPanel.add(addEmployeePanel, "addEmployee");
        contentPanel.add(requestLeavePanel, "requestLeave");
        contentPanel.add(approveLeavePanel, "approveLeave");

        add(contentPanel);
    }

    public void showPanel(String panelName) {
        if (panelName.equals("main")) {
            mainPanel.updateData(currentUser);
        }
        cardLayout.show(contentPanel, panelName);
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
        if (user != null) {
            mainPanel.updateData(user);
        }
    }


    public User getCurrentUser() {
        return currentUser;
    }

    public void updateMainPanel() {
        mainPanel.updateData(currentUser);
    }

    public void showRequestLeavePanel() {
        showPanel("requestLeave");
    }

    public void showApproveLeavePanel() {
        showPanel("approveLeave");
    }

    public void logout() {
        setCurrentUser(null); // Mettre currentUser à null sans accéder à ses propriétés
        showPanel("login");
    }

    public void showUpdateEmployeePanel(Employee employee) {
        if (employee != null) {
            updateEmployeePanel = new UpdateEmployeePanel(this, employee);
            contentPanel.add(updateEmployeePanel, "updateEmployee");
            showPanel("updateEmployee");
        } else {
            JOptionPane.showMessageDialog(this, "Employé non valide.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}
