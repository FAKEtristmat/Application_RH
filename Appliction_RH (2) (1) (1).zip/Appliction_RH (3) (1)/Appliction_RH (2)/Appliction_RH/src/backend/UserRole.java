package backend;

public enum UserRole {
    ADMIN,
    MANAGER,
    EMPLOYEE
}