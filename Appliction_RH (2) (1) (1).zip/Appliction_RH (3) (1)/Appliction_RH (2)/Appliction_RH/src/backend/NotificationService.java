package backend;

import java.io.*;
import java.util.*;

import backend.Notification;


public class NotificationService {
    private static final String NOTIFS_FILE = "data/notifications.csv";

    public static void addNotification(Notification notif) {
        List<Notification> notifs = loadAll();
        long maxId = 0;
        for (Notification n : notifs) {
            if (n.getId() > maxId) {
                maxId = n.getId();
            }
        }
        notif.setId(maxId + 1);
        notifs.add(notif);
        saveAll(notifs);
    }

    public static List<Notification> getUnreadNotifications(Long userId) {
        List<Notification> notifs = loadAll();
        List<Notification> result = new ArrayList<>();
        for (Notification n : notifs) {
            if (!n.isRead() && n.getUserId().equals(userId)) {
                result.add(n);
            }
        }
        return result;
    }

    public static void markAsRead(Long notifId) {
        List<Notification> notifs = loadAll();
        for (Notification n : notifs) {
            if (n.getId().equals(notifId)) {
                n.setRead(true);
            }
        }
        saveAll(notifs);
    }

    private static List<Notification> loadAll() {
        List<Notification> result = new ArrayList<>();
        File file = new File(NOTIFS_FILE);
        if (!file.exists()) {
            return result;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null && !line.trim().isEmpty()) {
                String[] parts = line.split(",", 4);
                if (parts.length < 4) continue;
                Long id = Long.parseLong(parts[0].trim());
                Long userId = Long.parseLong(parts[1].trim());
                String message = parts[2].trim();
                boolean read = Boolean.parseBoolean(parts[3].trim());
                result.add(new Notification(id, userId, message, read));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    private static void saveAll(List<Notification> notifs) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(NOTIFS_FILE))) {
            for (Notification n : notifs) {
                // Remplacer les virgules dans le message pour ne pas casser le CSV
                String msg = n.getMessage().replace(",", " ");
                pw.println(n.getId() + "," + n.getUserId() + "," + msg + "," + n.isRead());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
